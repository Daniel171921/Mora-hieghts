<?php
   include_once "dcon.php"; //include the file which contain database conecction 
   /**
    * The following code(line 7 to 11) redirected the user to its respective home page 
    * if it is already there logged in
    */
    if(isset($_SESSION['idno'])) // to check whether the session variable is or not
    {                            // it identifies whether the user signed in or not
        $role=$_SESSION['role']; // 
        header("Location:$role.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <title>AMS</title>
 
</head>
<body>
    <div class="container">
        <div class="logo">
            
           <h2> Assignment Management System </h2>
           <h3>Faculty of Computing and Sofwtare Engineering</h3>
            
        </div>
        <div class="myform">
            <h2>Sign in</h2>
            <form action="#" method="post">
                <input type="text" name="idno" placeholder="idno" id="" required>
                <input type="password" name="password" placeholder="passord" id="" required>
                <input type="submit" value="Sign in" name="signin">

                <p>You don't have account? <a href="signup.php"> Sign Up</a></p>
            </form>
            <?php
                if(isset($_POST['signin']))
                {
                        $idno=cleanData($_POST['idno']);
                        $password=$_POST['password'];
                        $password=md5($password);
                        $sql="SELECT * FROM `account` WHERE idno='$idno' and password='$password'";
                        $query=mysqli_query($con,$sql);
                        $nor=mysqli_num_rows($query);
                        if($nor>0)
                        {
                           $result=mysqli_fetch_array($query);
                           $role=$result['role'];

                           $_SESSION['idno']=$idno;
                           $_SESSION['role']=$role;


                            if($role=='student')
                            {
                                header("Location:student.php");
                            }
                            if($role=='staff')
                            {
                                header("Location:staff.php");
                            }
                        }
                        else{
                            echo"<i style='color:red'> Incorrect idno or password</i>";
                        }


                }
            ?>
        </div>

    </div>
    <?php print_r($_SESSION);?>
    <footer>
      AMU/FCSE   &copy; 2023 
    </footer>
</body>
</html>
<?php print_r($_SESSION);?>