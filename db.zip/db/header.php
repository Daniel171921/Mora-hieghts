<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/fontawesome-free-5.15.4-web/css/all.css">
        <link rel="stylesheet" href="css/menu.css">
         <link rel="stylesheet" href="css/home.css">
    <style>
         table th{
        border-bottom:solid 1px black;
    }
    table td{
        border-right:solid 1px black;
    }
    #con_profile
    {
        width:50px;
        border-radius:50%
    }
    </style>
    <title>AMS (<?=$role?> page)</title>
</head>
<body>
<div class="navbar">
    
    <a  href="index.php" style="float: left;"><i class="fa fa-fw fa-home"></i>AMS (<?=$role?> page)</a>
    <form action="logout.php" method="get"><input type="submit" value="logout" name="logout"></form>
    
    <a href="#"><i class="fa fa-fw fa-user"></i><?=$idno?></a>
    
    
  </div>