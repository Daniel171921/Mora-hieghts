                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <?php
  if(isset($_POST['register'])){
        $fname=cleanData($_POST['fname']);
        $mname=cleanData($_POST['mname']);
        $lname=cleanData($_POST['lname']);
        $idno=cleanData($_POST['idno']);
        $role=$_POST['role'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        if($password!=$cpassword)
        {
            die("password must be match");
        }
        $sql7="select * from account where idno='$idno'";
        $query7=mysqli_query($con,$sql7);
        $num_r=mysqli_num_rows( $query7);
        if($num_r>0)
        {
            echo "already exists";
        }
        else{
            $password=md5($password);
            $sql="INSERT INTO `account`(`idno`, `password`, `role`, `status`) VALUES ('$idno','$password','$role',DEFAULT);";
            $sql.="INSERT INTO `profile`(`fname`, `mname`, `lname`, `idno`) VALUES ('$fname','$mname','$lname','$idno')";
            $query=mysqli_multi_query($con,$sql);
            if($query)
            {
                header("Location:index.php");
            }
            else{
                echo "Error";
            }
    }




}


?>