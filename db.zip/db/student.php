<?php
    include_once "dcon.php";
    if(!isset($_SESSION['idno']))
    {
        header("Location:index.php");
    }
    else{
            if(!isset($_SESSION['role']))
            {
                header("Location:index.php");
            }

            $idno=$_SESSION['idno'];
            $role=$_SESSION['role'];
            if($role!="student")
            {
                header("Location:$role.php");
            }
    }

?>
<?php
    include_once "header.php";
?>
  <div class="container">
    <div class="logo" style="padding: 0em 0em;">
        <div class="topmenu" style="position: relative; top: 0px;right: 0;"> 
            <a href="#"> </a> 
            </div>
     <div class="logo">
            
            <h2> Assignment Management System </h2>
            <h3>Faculty of Computing and Software Engineering</h3>
             
         </div>
        
    </div>
        <div class="myform" style="padding: 0em 0em;">
            <div class="topmenu" style="position: relative; top: 0px;right: 0;"> 
            <a href="javascript:uploadFunction()"   ><i class="fa fa-fw fa-upload"></i> Submit Assignment</a> 
            <a href="#" onclick="viewFunction()" class="active" ><i class="fa fa-fw fa-eye"></i> View Submitted Lists</a> 
        </div>
        <div id="view">
        <table id="">
                    <tr>
                        <th>S.No.</th>
                        
                        <th>Title </th>
                        <th>Submission Date and Time</th>
                        <th>Action</th>
                        
                    </tr>
                    <tr>
                        <?php
                         // to get the assignment information where the assignment is submitted by the current user
                                $sql5="SELECT * FROM `assigment` where submitted_by = '$idno'";
                                $query5=mysqli_query($con,$sql5);
                                $counter=1;
                                while($row=mysqli_fetch_array($query5))
                                { ?>
                                    <td><?=$counter?></td>
                                    <td> <?=$row['title'] ?></td>
                                    <td> <?=$row['date'] ?></td>
                                    <td> <a href="<?=$row['file'] ?>"> <i class="fa fa-fw fa-download"> </i></a> <a href="student.php?del=<?=$row['id']?>" ><i class="fa fa-fw fa-trash"></i></a></td>
                                 
                           <?php     
                           $counter++;
                           }

                            ?>
                      
                    </tr>
        </table>

      </div>
        <div id="upload">
        <form action="#" method="post" enctype="multipart/form-data">
                <input type="text" name="staff" placeholder="Instructor name" id="staffid"list="staff" required >
                <input type="text" name="title" placeholder="Assignment Title" id="title" required>
                <input type="file" name="file" placeholder="Assignment File" id="file" required>
                <input type="submit" name="upload" placeholder="upload file" id="upload_file" required>
                
                <datalist id="staff">
                <option value="">select</option>
                    <?php
                       // select the staffs into datalist to allow the students to select from the list
                        $sql2="select * from account where role = 'staff'";
                        $query2=mysqli_query($con,$sql2);
                        while($row=mysqli_fetch_array($query2))
                        {
                            $staff_id=$row['idno'];
                            $sql3="select * from profile where idno = '$staff_id'";
                            $query3=mysqli_query($con,$sql3);
                            $res=mysqli_fetch_array($query3);
                            $fname=$res['fname'];
                            $mname=$res['mname'];
                            $lname=$res['lname'];
                            echo "<option value='$staff_id'>$fname $mname</option>";

                        }


                    ?>
              
                </datalist>
        </form>
        <?php
            if(isset($_POST['upload']))
            {
                $staff=$_POST['staff'];
                $title=$_POST['title'];
                $filename=$_FILES['file']['name'];
                $filetemp=$_FILES['file']['tmp_name'];
                if(move_uploaded_file($filetemp,"assignment/".$filename))
                {
                    $path= "assignment/".$filename;
                    $sql4="INSERT INTO `assigment`(`id`, `title`, `file`, `submitted_by`, `submitted_to`, `date`) VALUES (DEFAULT,'$title','$path','$idno','$staff',DEFAULT)";
                    $query4=mysqli_query($con,$sql4) or die("unable register");
                   
                }
                else{
                    echo "unable to upload file";
                }
               
            }
            if(isset($_GET['del']))
            {
                $fileid=$_GET['del'];
                $sql6="delete from assigment where id=$fileid";
                $query6=mysqli_query($con,$sql6) or die("unable to delete assigment");
                header("Location:student.php");
            }
        ?>

      </div>
    
    </div>
    <script>
        var upload=document.getElementById("upload");
        var view=document.getElementById("view");
        upload.style.display="none";
        function uploadFunction(){
                view.style.display="none";
                upload.style.display="block";
        }
        function viewFunction(){
                view.style.display="block";
                upload.style.display="none";
        }

    </script>
<?php
    include_once "footer.php";
?>