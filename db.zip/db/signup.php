<?php
    include_once "dcon.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style2.css">
    <style>
        #namerr,#iderror,#passerr,#cpasserr{
            color:red;
        }
    </style>

    <title>AMS</title>
</head>
<body>
    <div class="container">
    <div class="logo">
            
            <h2> Assignment Management System </h2>
            <h3>Faculty of Computing and Sofwtare Engineering</h3>
             
         </div>
        <div class="myform">
            <h2>Sign Up</h2>
            <form action="#" method="post" >
                <input type="text" name="fname" placeholder="First name" id="fname" required> <span id="namerr"></span>
                <input type="text" name="mname" placeholder="Middle name" id="mname" required> <span id="namerr"></span>
                <input type="text" name="lname" placeholder="Last name" id="lname" required> <span id="namerr"></span>
                <input type="text" name="idno" placeholder="Idno" id="idno" required> <span id="iderror"></span>
                <input type="password" name="password" placeholder="passord" id="password" required> <span id="passerr"></span>
                <input type="password" name="cpassword" placeholder="confirm password" id="cpassword" required> <span id="cpasserr"></span>
                <select name="role" id="">
                    <option>select role</option>
                    <option value="student">Student</option>
                    <option value="staff">Staff</option>
                </select>
                <input type="submit" value="Register" name="register">

                <p>Do You have an account? <a href="index.php"> Sign in</a></p>

            </form>
        </div>
        <?php
          include "register.php";

        ?>

    </div>
   
    <footer>
         AMU/FCSE &copy; 2023
    </footer> 
    
</body>
</html>