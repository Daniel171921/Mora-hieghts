<?php
    include_once "dcon.php";
 /**
    * The following code(line 7 to 11) redirected the user to its respective home page 
    * if it is already there logged in based on their role and also it redirects back to
    * the login page if it is not authenticated
    */
    if(!isset($_SESSION['idno']))
    {
        header("Location:index.php"); // redirects back to the login page(index.php) if it is not authenticated
    }
    else
    {
        if(!isset($_SESSION['role']))
        {
            header("Location:index.php");
        }
        $idno=$_SESSION['idno'];
        $role=$_SESSION['role'];
        if($role!="staff")
        {
            header("Location:$role.php");
        }
    }

?>
<?php
    include_once "header.php";
?>
  <div class="container">
    <div class="logo" style="padding: 0em 0em;">
        <div class="topmenu" style="position: relative; top: 0px;right: 0;"> 
            <a href="#"> </a> 
            </div>
     <div class="logo">
            
            <h2> Assignment Management System </h2>
            <h3>Faculty of Computing and Sofwtare Engineering</h3>
             
         </div>
        
    </div>
        <div class="myform" style="padding: 0em 0em;">
            <div class="topmenu" style="position: relative; top: 0px;right: 0;"> 
            <a href="#" class="active" ><i class="fa fa-fw fa-download"></i> Submitted Assignment Lists</a> 
        </div>
        <table id="">
                    <tr>
                        <th>S.No.</th>
                        
                        <th>Title </th>
                        <th>Student Idno </th>
                        <th>Submission Date and Time</th>
                        <th>Action</th>
                        
                    </tr>
                    <tr>
                        <?php
                         // to get the assignment information where the assignment is submitted to the current user
                                $sql5="SELECT * FROM `assigment` where submitted_to = '$idno'";
                                $query5=mysqli_query($con,$sql5);
                                $counter=1;
                                while($row=mysqli_fetch_array($query5))
                                { ?>
                                    <td><?=$counter?></td>
                                    <td> <?=$row['title'] ?></td>
                                    <td> <?=$row['submitted_by'] ?></td>
                                    <td> <?=$row['date'] ?></td>
                                    <td> <a href="<?=$row['file'] ?>"> <i class="fa fa-fw fa-download"> </i></a> </td>
                                 
                           <?php     
                           $counter++;
                           }

                            ?>
                      
                    </tr>
        </table>

    
    
    </div>
</div>
<?php
    include_once "footer.php";
?>
$nati=password_hash($_POST["password"], PASSWORD_DEFAULT);