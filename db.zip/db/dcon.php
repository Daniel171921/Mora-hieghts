<?php
    $host="localhost";
    $user="root";
    $password="";
    $dbname="ams";
    $con=mysqli_connect($host,$user,$password,$dbname) or die("Couldn't connect to the db");
    function cleanData($data)
    {
            $data=htmlspecialchars($data);
            $data=trim($data);
            $data=stripslashes($data);
            return $data;
    }
    session_start();