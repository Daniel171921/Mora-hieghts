<?php
    session_start();
    require '../_database/database.php';
    session_destroy();
    header('location:/../pages/Auth/login.php?logout=success');
?>