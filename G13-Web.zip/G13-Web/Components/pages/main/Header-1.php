<div class="nav-box">
    <div class="content">
        <a href="home.php" class="logo">
            <img src="../../assets/images/Home/home-logo.svg" alt="" width="50px">
        </a>
        <div class="search">
                <span class="searchIcon">
                    <img src="../../assets/images/Home/icons8-search.svg" alt="search" width="30px">
                </span>
            <div class="form">
                <input id='search-input' type="text" class="form-control form-input" placeholder="Search"/>
            </div>
        </div>
        <div class="navBar">
            <div class="navList-wrapper">
                <div class="navList">
                    <a href="">
                        <img src="../../assets/images/Home/home-svgrepo-com.svg" alt="home">
                        <span>Home</span>
                    </a>
                </div>
                <div class="navList">
                    <a href="">
                        <img src="../../assets/images/Home/work-ui-job-svgrepo-com.svg" alt="jobs">
                        <span>Jobs</span>
                    </a>
                </div>
                <div class="navList">
                    <a href="">
                        <img src="../../assets/images/Home/resume-svgrepo-com.svg" alt="resume">
                        <span>Resume</span>
                    </a>
                </div>
                <div class="navList">
                    <a href="">
                        <img src="../../assets/images/Home/message-27.svg" alt="messages">
                        <span>Messages</span>
                    </a>
                </div>
                <div class="navList">
                    <a href="">
                        <img src="../../assets/images/Home/notification-15.svg" alt="notification">
                        <span>Notification</span>
                    </a>
                </div>
                <div class="navList">
                    <a href="">
                        <img src="../../assets/images/Home/person-17.svg" alt="person">
                        <span>Profile</span>
                    </a>
                </div>
            </div>

        </div>
        <button class="employer">
            <a href="">
                <span>Employers</span>
            </a>
        </button>
    </div>
</div>