<nav class="nav-bar">
    <a href="../../index.php">
        <img src="../../assets/images/Home/home-logo.svg" alt="" width='50px'/>
    </a>
</nav>