<?php
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $database = "omotic-jobs-g13";
    $prefix = "";
    $db1=new mysqli($hostname,$user,$password,$database);
?>
